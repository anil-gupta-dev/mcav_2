<?php

namespace App\Models;

use Eloquent as Model;



class ImportedExcelData extends Model
{
    //
    public $table = 'imported_excel_data';
        public $timestamps = false;
        
       


}
