<?php

namespace App\Models;

use Eloquent as Model;



class CurlFetchExcelLog extends Model
{
    //
    public $table = 'curl_fetch_excel_log';
        public $timestamps = false;
        
       


}
