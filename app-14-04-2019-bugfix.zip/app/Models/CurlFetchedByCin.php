<?php

namespace App\Models;

use Eloquent as Model;



class CurlFetchedByCin extends Model
{
    //
    public $table = 'curl_fetched_by_cin';
        public $timestamps = false;
        
       


}
