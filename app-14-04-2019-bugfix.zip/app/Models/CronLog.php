<?php

namespace App\Models;

use Eloquent as Model;



class CronLog extends Model
{
    
    public $table = 'cron_log';
        public $timestamps = false;
        
       


}
